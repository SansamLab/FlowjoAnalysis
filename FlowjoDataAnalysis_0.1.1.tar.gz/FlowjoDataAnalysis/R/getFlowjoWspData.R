#' Pull out specific data from flowjo workspace
#'
#' Given a flowjo workspace and a list of .fcs files this code will generate a list of dataframes and specific gates can be specified.
#'
#' @param wspFilename wsp file that includes gating setting and other data from flowjo
#' @param fcsPath fcs path should be the directory where all the fcs files are saved
#' @param fcsPattern the fcs pattern will be .fcs and is used to load in the .fcs data
#' @param nodes nodes specifies the gate being used for the analysis
#' @param markers marker specifies the columns of data you want back. Ex: FSC-A, SSC-A, FL1-A
#' @return A list of data frames with all the data specific to each gate. Each item in the list is a different samlpe and each data frame has the raw data.
#' @export

getFlowjoWspData <-  function(wspFilename="04-Oct-2021.wsp",
         fcsPath=".",
         fcsPattern=".fcs",
         nodes="Cells",
         markers=c("FSC-A","SSC-A","FL1-A"))
  {
  # load workspace
  data <- CytoML::open_flowjo_xml(wspFilename)
  # load .fcs files
  myfiles <- list.files(path=fcsPath, pattern=fcsPattern)
  fs <- flowCore::read.flowSet(myfiles, path=fcsPath)
  # parse workspace and fcs files
  gs <- CytoML::flowjo_to_gatingset(data, name = 2)
  # put data
  df3 <- flowWorkspace::gs_get_singlecell_expression_by_gate(x=gs, nodes=nodes, other.markers=markers, threshold = FALSE)
  names(df3) <- gsub("\\..*","",names(df3))
  # add names to last column and remove excess columns
  df3names <- lapply(names(df3), function(x) {
    df <- as.data.frame(df3[[x]])
    df$Sample <- x
    df <- df[,-c(1,2)]
    return(df)
  })
  names(df3) <- gsub("\\..*","",names(df3))
  return(df3)
}
